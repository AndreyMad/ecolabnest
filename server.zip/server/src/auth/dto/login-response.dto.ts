export interface LoginResponseDto {
  readonly userId: number;
  readonly access_token: string;
}
