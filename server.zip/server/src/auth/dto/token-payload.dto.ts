export interface TokenPayloadDto {
  readonly id: number;
  readonly email: string;
}
